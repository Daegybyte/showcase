#pragma once
#include <string>

std::string random_expr_print();
std::string toZero();
std::string addRand();
std::string multRand();
std::string whiteSpace();
std::string randNum();
std::string checkParentheses();