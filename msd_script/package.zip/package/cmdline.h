#pragma once
#include "pointer.h"

/**
 * Takes in arguments from the command line
 * @param argc number of arguments
 * @param argv the argument being passed
 */
void use_arguments(int argc, char *argv[]);